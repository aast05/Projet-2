var setupListeners = function() {
	var button = document.getElementById("validation");
	button.addEventListener("click",modification);
}

window.addEventListener("load",setupListeners); //évenement déclenché lorsque la page est chargée


//**************************FONCTIONS LISTENERS**************************************************************************


/*fonction va qui modifier les paramètres saisie par l'utilisateur en allant modifier ses données dans la base de donnée
  sans recharger la page
*/ 
var modification = function() {
    
	var xhr = new XMLHttpRequest(); //on instancie un objet xhlhttprequest
	xhr.open("POST","../lib/requeteModifProfil.php"); //ouverture du fichier qui va envoyer la requete, via la méthode post
	
	/*on récupère les valeurs saisies par l'utilisateur*/
	var login = document.getElementById("login").value; 
        document.getElementById("login").value =""; 
	var nom = document.getElementById("nom").value;
	var prenom = document.getElementById("prenom").value;
	var description = document.getElementById("description").value;
	xhr.addEventListener("readystatechange",traiteReponse);//on lance un événement pour savoir l'état de la requête
	xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"); //modification du mimetype de la page
	xhr.send("login="+login+"&nom="+nom+"&prenom="+prenom+"&description="+description);
}

/*fonction qui va traiter la réponse en fonction du l'état de la requete*/
var traiteReponse = function() {
	if(this.readyState===XMLHttpRequest.DONE && this.status===200) {
		var contenu = document.getElementById("contenu");
		contenu.innerHTML = this.responseText;
	}
	
}
