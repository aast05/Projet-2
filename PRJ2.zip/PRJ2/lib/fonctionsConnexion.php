<?php
#####################################################
#                                                   #
#   Senoussi Assim Tarek & Sansaoui Yassine         #
#   Copyright © 2016 All rights reserved            #
#                                                   #
#####################################################

require_once("../classes/Membre.class.php");
require_once("bddConnexion.php");

session_start();
/*fonction qui retourne un objet Membre si l'utilisateur fourni un bon login et mot de passe
 *
 * $login: login de l'utilisateur
 * $password: mot de passe de l'utilisateur
 */
function authentification($login,$password) {
	global $bdd;
    $req = $bdd->prepare("SELECT * FROM membres WHERE login = ? AND password = ?");
    $req->execute(array($login,$password));
    if($donnee=$req->fetch()) { //si le login et le mot de passe correspondent dans la table
		$id = $donnee["id_membre"];
        $nom = $donnee["nom"];
        $prenom = $donnee["prenom"];
        $description = $donnee["description"];
        return new Membre($id,$nom,$prenom,$login,$password,$description);
    }
    return null;    
}

/*fonction qui intégre un objet membre dans une session si le login et le mot de passe fourni correspondent*/
function controleAuthentification() {
    if(isset($_SESSION["membre"])) {// si l'utilisateur est déjà connecté il ne se passe rien
        return;
    }
    else if(isset($_REQUEST["login"]) && isset($_REQUEST["password"])) {//si les variables de formulaires existent
        $login = $_REQUEST["login"];
        $password = $_REQUEST["password"];
        if(authentification($login,$password)!==null) { //si l'authentification est réussie
            $_SESSION["membre"] = authentification($login,$password);
            return;
        }   
        else {
			throw new Exception("Le login ou le mot de passe fourni n'existe pas");
		}
    }
    throw new Exception("Merci de remplir les champs suivants");     
}
 

?>
