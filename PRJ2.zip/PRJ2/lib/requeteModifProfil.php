<?php
#####################################################
#                                                   #
#   Senoussi Assim Tarek & Sansaoui Yassine         #
#   Copyright © 2016 All rights reserved            #
#                                                   #
#####################################################


require_once("bddConnexion.php");
require_once("../classes/Membre.class.php");
require_once("infosMembre.php");

session_start();


//*************modification du login***************
if(isset($_POST["login"])) {
	$nouveauLogin = $_POST["login"]; //nouveau login
	try {
		$membre->setLogin($nouveauLogin);//on modifie l'objet actuel du membre
		echo "Modification prise en compte";
	}
	catch(Exception $e) {
		echo $e->getMessage(); //si erreur, message d'erreur envoyé
	}
}

//*************modification du nom****************
if(isset($_POST["nom"])) {
	
	
}

?>

	
