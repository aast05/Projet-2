<?php
#####################################################
#                                                   #
#   Senoussi Assim Tarek & Sansaoui Yassine         #
#   Copyright © 2016 All rights reserved            #
#                                                   #
#####################################################


//*********************Connexion à la base de donnée********************************
try {
    $bdd = new PDO("pgsql:host=localhost;dbname=sansaoui","sansaoui","mamaroula007");
}
catch(Exception $e) {
    echo "Erreur: ".$e->getMessage();
    exit();
}

?>
