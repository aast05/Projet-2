<?php
require_once("../classes/Membre.class.php");

session_start();

/*informations sur l'utilisateur connecté*/
if(isset($_SESSION["membre"])) { //si le membre est conncecté
    $membre = $_SESSION["membre"];
    $idMembre = $membre->getId();
    $nomMembre = $membre->getNom();
    $prenomMembre = $membre->getPrenom();
    $loginMembre= $membre->getLogin();
    $passwordMembre = $membre->getPassword();
}
?>
