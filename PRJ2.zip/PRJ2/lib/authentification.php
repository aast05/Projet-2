<?php

//****************Controle d'authentification de l'utilisateur********************
require_once("fonctionsConnexion.php");

try {
	controleAuthentification();//on voit si l'utilisateur est connecté
}
catch(Exception $e) { //en cas d'échec on renvoit un message d'erreur et le formulaire de connexion
	echo $e->getMessage();
	require("../includes/connexion.php");
	exit();
}

?>
