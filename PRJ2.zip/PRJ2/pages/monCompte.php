<?php
#####################################################
#                                                   #
#   Senoussi Assim Tarek & Sansaoui Yassine         #
#   Copyright © 2016 All rights reserved            #
#                                                   #
#####################################################

require_once("../lib/authentification.php");

?>

<DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href=""/>
        <title>Modifier mon profil</title>    
    </head>
	
    <body>
		<header>
			<!--****************MENU***************-->
			<?php include("../includes/nav.php"); ?>
			<!--***********************************-->
		</header>
		
			<ul>
				<li><a href="modifierProfil.php">Modifier</a></li>
			</ul>
	</body>
</html>
