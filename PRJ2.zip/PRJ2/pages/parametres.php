﻿<?php
#####################################################
#                                                   #
#   Senoussi Assim Tarek & Sansaoui Yassine         #
#   Copyright © 2016 All rights reserved            #
#                                                   #
#####################################################

require_once("../lib/authentification.php");
require_once("../lib/bddConnexion.php");
require_once("../lib/infosMembre.php");
session_start();

$pas_en_cours = "parametres";
//------------------modification mot de passe----------------------
if(!empty($_POST["password"]) && !empty($_POST["newpassword"])) { //si l'ancien et nouveau mot de passe ont été fourni
	$password = $_POST["password"];
    $req = $bdd->prepare("SELECT password FROM membres WHERE login = ?");//on sélectionne le password de l'utilisateur
    $req->execute(array($loginMembre));
    $donnee=$req->fetch();
    $req->closeCursor();
    if($donnee["password"]==$password) {
		$insertionPassword=$bdd->prepare("UPDATE membres SET password=? WHERE login= ?");//mise à jour du password
		$insertionPassword->execute(array($passwordMembre,$loginMembre));
		$insertionPassword->closeCursor();
		echo "Mot de passe modifié avec succès";
	}
	else {
		echo "L'ancien mot de passe ne correspond pas";
	}
}


//---------------------modification avatar--------------------------
if(isset($_FILES["avatar"])) {
    define("REP","../images/avatars/");
    if(!file_exists(REP)) { //si le dossier qui va contenir les images d'avatars n'existe pas on le crée
        mkdir(REP,0777,true);
    }
    $extension = strtolower(strrchr($_FILES["avatar"]["name"],'.'));//extension de l'image (.png,.jpg...)
    $imgName = REP.$loginMembre.$extension; //nom de l'image transférée
    $resultat = move_uploaded_file($_FILES["avatar"]["tmp_name"],$imgName);//déplacement du fichier dans le dossier du serveur
    if($resultat) {
        echo "Transert de l'image réussi";
    }
    else {
        echo "Echec du transfert";
    }  
}

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href=""/>
        <title>Paramètres</title>
    </head>
    
    <body>
		<header>
		<!--****************MENU***************-->
			<?php include("../includes/nav.php"); ?>
		<!--***********************************-->
		</header>
		
        <!--changement de mot de passe-->
        <form method="post" action="">
            <fieldset>
                <legend>Changer mon mot de passe</legend>
                
                <label for="password">Ancien mot de passe: </label>
                <input type="password" id="password" name="password" require="required"/>
                
                <label for="newpassword">Nouveau mot de passe: </label>
                <input type="password" id="newpassword" name="newpassword" required="required"/>
                
                <button type="submit">Changer mon mot de passe</button>
            </fieldset>
        </form>
        
        <!--changement d'avatar-->
        <form method="post" action="" enctype="multipart/form-data">
            <fieldset>
                <legend>Modifier mon avatar</legend>
                
                <input type="hidden" name="MAX_FILE_SIZE" value=""/> <!--taille de l'image à fournir-->
                <input type="file" id="avatar" name="avatar"/>
                
                <button type="submit">Modifier mon avatar</button>
            </fieldset>
        </form>
    </body>

</html>
