<?php
#####################################################
#                                                   #
#   Senoussi Assim Tarek & Sansaoui Yassine         #
#   Copyright © 2016 All rights reserved            #
#                                                   #
#####################################################

session_start();

header("Location: index.php");
if(isset($_SESSION["membre"])) {
	unset($_SESSION["membre"]);
	session_destroy();
}
