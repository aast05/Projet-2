<?php
#####################################################
#                                                   #
#   Senoussi Assim Tarek & Sansaoui Yassine         #
#   Copyright © 2016 All rights reserved            #
#                                                   #
#####################################################

require_once("../lib/bddConnexion.php"); //connexion base de donnée

$champs = array("nom","prenom","login","password","description"); //champs du formulaire 
$erreurs = array_fill_keys($champs,FALSE); //aucune erreur à l'initialisation
$messagesErreurs = array_fill_keys($champs,"");
$nbErreurs = 0; //nombre d'erreur à 0

if(isset($_POST["nom"]) && isset($_POST["prenom"]) && isset($_POST["login"]) && isset($_POST["password"]) && isset($_POST["description"])) {
	//on parcourt le tableau de champs d'erreurs
	foreach($erreurs as $key=>$val) {
		if(empty($_POST[$key])) {
			$erreurs[$key] = TRUE; //si le champs n'est pas rempli alors erreur
			$nbErreurs++;
			$messagesErreurs[$key] = "Merci de remplir le champs ".$key;
		}
	}
	
	//si aucune erreur on ajoute le nouveau membre
	if($nbErreurs === 0) {
		
		/*on converti les caractères spéciaux de toutes les données reçues*/
		$nom = htmlspecialchars($_POST["nom"]);
		$prenom = htmlspecialchars($_POST["prenom"]);
		$login = htmlspecialchars($_POST["login"]);
		$password = htmlspecialchars($_POST["password"]);
		$description = htmlspecialchars($_POST["description"]);
		
		
		/*fonction qui vérifie si le login existe déjà*/ 
		function loginExiste($login) {
			global $bdd;
			$verifLogin = $bdd->query("SELECT login FROM membres");
			while($donnee = $verifLogin->fetch()) {
				if($donnee["login"]==$login) {
					return true;
				}
			}
			return false;
		}
		
		//on vérifi sur le login existe déjà dans la table
		if(!loginExiste($login)) {
			//ajout du membre dans la table
			$req = $bdd->prepare("INSERT INTO membres(nom,prenom,login,password,description) 
								  VALUES(:nom,:prenom,:login,:password,:description)");
			$req->execute(array(
							"nom"=>$nom,
							"prenom"=>$prenom,
							"login"=>$login,
							"password"=>$password,
							"description"=>$description));
			$req->closeCursor(); //on ferme la requête sql
			echo "Inscription effectuée";
		}
		else {
			echo "Le login entré existe déjà";
		}
	}
}

?>

<DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href=""/>
        <title>Inscription</title>    
    </head>
	
    <body>
		<!--**********FORMULAIRE D'INSCRIPTION***************-->
		<form method="post" action="">
			
			<label for="nom">Nom: </label>
			<input type="text" name="nom" id="nom" required="required" pattern="[a-zA-Z]{3,20}"/><br/>
			
			<label for="prenom">Prénom: </label>
			<input type="text" name="prenom" id="prenom" required="required" pattern="[a-zA-Z]{3,20}"/><br/>
			
			<label for="login">Login: </label>
			<input type="text" name="login" id="login" required="required" pattern="[a-zA-Z]{4,10}"/><br/>
			
			<label for="password">Password: </label>
			<input type="password" name="password" id="password" required="required" pattern="[a-zA-Z]{5,20}"/><br/>
			
			<label for="description">Description rapide de toi :</label>
			<textarea name="description" id="description"></textarea><br/>
			
			<button type="submit">S'inscrire</button>
			<button type="reset">Tout Effacer</button>
		</form>
    </body>
</html>
