<?
#####################################################
#                                                   #
#   Senoussi Assim Tarek & Sansaoui Yassine         #
#   Copyright © 2016 All rights reserved            #
#                                                   #
#####################################################

require_once("../lib/authentification.php");

?>

<DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href=""/>
        <script src="../js/modifierProfil.js"></script>
        <title>Modifier mon profil</title>    
    </head>
	
    <body>
		<header>
			<!--****************MENU***************-->
			<?php include("../includes/nav.php"); ?>
			<!--***********************************-->
		</header>
		
		<div id="contenu"></div>
		
		<!--modificaton du profil du membre-->
		<form method="post" action="">
			<label for="login">Login</label>
			<input type="text" id="login" name="login"/><br/>
			
			<label for="nom">Nom</label>
			<input type="nom" id="nom" name="nom"/><br/>
			
			<label for="prenom">Prénom</label>
			<input type="prenom" id="prenom" name="prenom"/><br/>
			
			<label for="description">Description</label>
			<textarea id="description" name="description"></textarea><br/>
				
			<input type="button" id="validation" value="Enregistrer"/>
		</form>	
	</body>
</html>
