<?php
#####################################################
#                                                   #
#   Senoussi Assim Tarek & Sansaoui Yassine         #
#   Copyright © 2016 All rights reserved            #
#                                                   #
#####################################################

require_once("../lib/fonctionsConnexion.php");
require_once("../lib/infosMembre.php");
session_start();

/*si l'utilisateur entre un login et un mot de passe*/
if(isset($_POST["login"]) && isset($_POST["password"])) {
	try {
		/*on controle son authentification*/
		controleAuthentification();
		/* si réussie on lui souhaite la bienvenue*/
		echo "Bienvenue ".$_SESSION["membre"]->getPrenom();
	}
	/*en cas d'echec d'authentification on  affiche un message d'erreur*/
	catch(Exception $e) {
		echo $e->getMessage();
	}
}

?>
<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href="../css/index.css"/>
        <title>Partage d'événements</title>
    </head>

    <body>
		<header>
			<!--****************MENU***************-->
			<?php include("../includes/nav.php"); ?>
			<!--***********************************-->
		</header>
       
        <div id="connexion">
            <!--*************Formulaire de connexion*************-->
           
           <?php 
           //si l'utilisateur n'est pas connecté on ajoute une barre de connexion à la page
			if(!isset($_SESSION["membre"])) { 
				require("../includes/connexion.php");
				echo "<a href='inscription.php'>Pas encore inscrit ?</a>";
			}
           ?>
        </div>
        
        <!--****************FOOTER***************-->
        <?php include("../includes/footer.php"); ?>
        <!--***********************************-->
        
    </body>
</html>
