<?php
#####################################################
#                                                   #
#   Senoussi Assim Tarek & Sansaoui Yassine         #
#   Copyright © 2016 All rights reserved            #
#                                                   #
#####################################################

session_start();
?>

<nav>
    <ul>
        <li><a href="index.php">Accueil</a></li>
        <li><a href="ajoutEvenement.php">Ajouter un événement</a></li>
        <li><a href="credit.html">Crédits</a></li>
        <?php
        if(isset($_SESSION["membre"])) {
		?>
                    <li><a href="monCompte.php">Mon Compte</a></li>
                    <ul>
                        <li><a href="parametres.php">Paramètres</a></li>
                        <li><a href="logout.php">Déconnexion</a></li>
                    <ul>
		<?php
		}
		?>
    </ul>
</nav>
