<?php
#####################################################
#                                                   #
#   Senoussi Assim Tarek & Sansaoui Yassine         #
#   Copyright © 2016 All rights reserved            #
#                                                   #
#####################################################
?>

<form method="post" action="">

	<label for="login">Login</label>
	<input type="text" id="login" name="login"/>
	
	<label for="password">Mot de passe</label>
	<input type="password" id="password" name="password"/>
	
	<button type="submit">Connexion</button>    
<form>
