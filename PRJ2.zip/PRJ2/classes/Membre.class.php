<?php
#####################################################
#                                                   #
#   Senoussi Assim Tarek & Sansaoui Yassine         #
#   Copyright © 2016 All rights reserved            #
#                                                   #
#####################################################


/*Classe membre qui va représenter l'utilisateur connecté*/

class Membre {
	private $id;
    private $nom;
    private $prenom;
    private $login;
    private $password;
    private $description;
    
    //_____constructor_____
    public function __construct($id,$nom,$prenom,$login,$password,$description) {
		$this->id = $id;
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->login = $login;
        $this->password = $password;
        $this->description = $description;
    }
    
    //_____getters______
    
    /*retourne l'id du membre*/
    public function getId() {
		return $this->id;
	}
	
	/*retourne le nom du mebre*/
    public function getNom() {
        return $this->nom;
    }
    
    /*retourne le prénom du membre*/
    public function getPrenom() {
        return $this->prenom;    
    }
    
    /*retourne le login du membre*/
    public function getLogin() {
        return $this->login;
    }
    
    /*retourne le password du membre*/
    public function getPassword() {
        return $this->login;
    }
    
    /*retourne la description du membre*/
    public function getDescription() {
        return $this->description;
    }
    
    //_____setters______
    
    /*modifie le nom du membre*/
    public function setNom($nom) {		
        $bdd = $this->connexionToBdd();
        $req=$bdd->prepare("UPDATE membres SET nom = ? WHERE login= ?");
        $req->execute(array($nom,$this->login));  
        $this->nom = $nom;  
    }
    
    /*modifie le prénom du membre*/
    public function setPrenom($prenom) {		
        $bdd = $this->connexionToBdd();
        $req=$bdd->prepare("UPDATE membres SET prenom = ? WHERE login= ?");
        $req->execute(array($prenom,$this->login));  
        $this->prenom = $prenom;
    }
    
    /*modifie le login du membre et renvoi une exception si le login existe déjà*/
    public function setLogin($login){
        $bdd = $this->connexionToBdd();
        $loginMembres = $bdd->query("SELECT login FROM membres");
		while($donnee=$loginMembres->fetch()) {
			if($donnee["login"]==$login) {
				throw new Exception("Le login entré existe déjà");
			}
		}	
        $req=$bdd->prepare("UPDATE membres SET login = ? WHERE login= ?");
        $req->execute(array($login,$this->login)); 
        $this->login = $login;	 
    }
    
    /*modifie le password du membre*/
    public function setPassword($password) {		
        $bdd = $this->connexionToBdd();
        $req=$bdd->prepare("UPDATE membres SET password = ? WHERE login= ?");
        $req->execute(array($password,$this->login));  
        $this->password = $password;
    }
    
    /*modifie la description du membre*/
    public function setDescription($description) {		
        $bdd = $this->connexionToBdd();
        $req=$bdd->prepare("UPDATE membres SET description = ? WHERE login= ?");
        $req->execute(array($description,$this->login));  
        $this->description = $description;
    }
    
    
    public function test() {
		$bdd = $this->connexionToBdd();
		$req=$bdd->prepare("SELECT nom FROM membres WHERE login = ?");
		$req->execute(array($this->login));
		$donnee= $req->fetch();
		echo $donnee["nom"];
	}
    
    //_____methode______
    
    /*fonction qui se connecte à la base de donnée*/
    public function connexionToBdd() {
        require("../lib/bddConnexion.php");
        return $bdd;
    }
}


?>
